<?php
$servername = "localhost"; // Cambia según tu configuración
$username = "root";
$password = "102003";
$dbname = "examen_p";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Manejo del formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $mensaje = $_POST['mensaje'];

    $sql = "INSERT INTO contacto (nombre, mensaje) VALUES ('$nombre', '$mensaje')";
    if ($conn->query($sql) === TRUE) {
        echo "Mensaje enviado exitosamente.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Obtener mensajes de la base de datos
$sql = "SELECT * FROM contacto";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto</title>
    <style>
        .container {
            display: flex;
        }
        .form-container, .messages-container {
            width: 50%;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2>Enviar Mensaje</h2>
            <form action="" method="post">
                <label for="nombre">Nombre:</label><br>
                <input type="text" id="nombre" name="nombre" required><br><br>
                <label for="mensaje">Mensaje:</label><br>
                <textarea id="mensaje" name="mensaje" required></textarea><br><br>
                <input type="submit" value="Enviar">
            </form>
        </div>

        <div class="messages-container">
            <h2>Mensajes Recibidos</h2>
            <table border="1">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Mensaje</th>
                    <th>Acciones</th>
                </tr>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['nombre']}</td>
                                <td>{$row['mensaje']}</td>
                                <td>
                                    <a href='modificar.php?id={$row['id']}'>Modificar</a>
                                    <a href='eliminar.php?id={$row['id']}'>Eliminar</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No hay mensajes.</td></tr>";
                }
                $conn->close();
                ?>
            </table>
        </div>
    </div>
</body>
</html>
