<?php
$servername = "localhost"; 
$username = "root";
$password = "102003";
$dbname = "examen_p";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $mensaje = $_POST['mensaje'];

    $sql = "UPDATE contacto SET nombre='$nombre', mensaje='$mensaje' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: conexion.php");
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM contacto WHERE id=$id");
    $row = $result->fetch_assoc();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Modificar Mensaje</title>
</head>
<body>
    <h2>Modificar Mensaje</h2>
    <form action="" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" value="<?php echo $row['nombre']; ?>" required><br><br>
        <label for="mensaje">Mensaje:</label><br>
        <textarea id="mensaje" name="mensaje" required><?php echo $row['mensaje']; ?></textarea><br><br>
        <input type="submit" value="Actualizar">
    </form>
</body>
</html>
